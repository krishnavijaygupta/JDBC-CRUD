
$("#id_email").keyup(function() {
	validatEmail();
});

$("#id_email").change(function() {
	validatEmail()
});

$("#id_pass").change(function() {
	passwordValidate()
});

$("#id_pass").keyup(function() {
	passwordValidate()
});

function isValidateData(){
	if(isValidateEmail && passwordValidatesss){
		alert("All good");
		return true;
	}else{
		alert("Invalid Data");
		return false;
	}
}
function passwordValidate(){
	let EMail = $("#id_pass").val();

	if(EMail.length==0){
		$("#p_password").text("Password Should not be Empty").css("color", "red");
		isPasswordValidate=false;
	}else{
		
		if(EMail.length<8){
			$("#p_password").text("Password Must be 8 digits").css("color", "red");
			isPasswordValidate=false;
		}else{	
			$("#p_password").text("Valid Password").css("color", "green");
			isPasswordValidate=true;
		}
	}
	
}

function validatEmail() {
	var re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
	let EMail = $("#id_email").val();
	required:true

	if (EMail.length !== 0) {
		if (!re.test(EMail)) {
			$("#p_email").text("Email not valid").css("color", "red");
			isValidateEmail=false;
		} else {
			$("#p_email").text("Email valid").css("color", "green");
			isValidateEmail=true;
		}
	} else {
		$("#p_email").text("Can't be empty").css("color", "red");
		isValidateEmail=false;
	}
}
