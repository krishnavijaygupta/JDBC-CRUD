
$("#id_email").keyup(function() {
	validatEmail();
});

$("#id_email").change(function() {
	validatEmail();
});

$("#id_pass").change(function() {
	passwordValidate();
});

$("#id_pass").keyup(function() {
	passwordValidate();
});



$("#fName").keyup(function() {
	validatfName();
});

$("#fName").change(function() {
	validatfName();
});

$("#lName").change(function() {
	ValidatelName();
});

$("#lName").keyup(function() {
	ValidatelName();
});



function validatfName(){
	
	let fname = $("#fName").val();

	if(fname.length==0){
		$("#p_fName").text("LirstName Should not be Empty").css("color", "red");
		isValidatefName=false;
	}else{
		
		if(fname.length<8){
			$("#p_fName").text("First Must be 5 digits").css("color", "red");
			isValidatefName=false;
		}else{	
			$("#p_fName").text("Valid FirstName").css("color", "green");
			isValidatefName=true;
		}
	}
	
}


function isValidatelName(){
	if(isValidatelName){
		alert("All good");
		return true;
	}else{
		alert("Invalid Data");
		return false;
	}
}
function ValidatelName(){
	let EMail = $("#lName").val();

	if(firstName.length==0){
		$("#p_lName").text("LastName Should not be Empty").css("color", "red");
		ValidatelName=false;
	}else{
		
		if(firstName.length<8){
			$("#p_lName").text("Last Must be 5 digits").css("color", "red");
			ValidatelName=false;
		}else{	
			$("#p_lName").text("Valid LastName").css("color", "green");
			ValidatelName=true;
		}
	}
	
}

function isValidateData(){
	if(isValidateEmail && passwordValidatesss){
		alert("All good");
		return true;
	}else{
		alert("Invalid Data");
		return false;
	}
}
function passwordValidate(){
	let EMail = $("#id_pass").val();

	if(EMail.length==0){
		$("#p_password").text("Password Should not be Empty").css("color", "red");
		isPasswordValidate=false;
	}else{
		
		if(EMail.length<8){
			$("#p_password").text("Password Must be 8 digits").css("color", "red");
			isPasswordValidate=false;
		}else{	
			$("#p_password").text("Valid Password").css("color", "green");
			isPasswordValidate=true;
		}
	}
	
}

function validatEmail() {
	var re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
	let EMail = $("#id_email").val();
	required:true

	if (EMail.length !== 0) {
		if (!re.test(EMail)) {
			$("#p_email").text("Email not valid").css("color", "red");
			isValidateEmail=false;
		} else {
			$("#p_email").text("Email valid").css("color", "green");
			isValidateEmail=true;
		}
	} else {
		$("#p_email").text("Can't be empty").css("color", "red");
		isValidateEmail=false;
	}
}
