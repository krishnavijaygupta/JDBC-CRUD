package com.milestone.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.milestone.model.UserModel;
import com.milestone.service.UserService;

/**
 * @author Sonu Kumar Gupta
 *
 */
@Controller
public class Usercontroller {

	/**
	 * User Service  
	 */
	@Autowired
	private UserService service;

	/** Show login page Type Url(http://localhost:8080/login)
	 * @return
	 */
	@Value("${file.path-pic}")

	@GetMapping("/login")
	public String login() {
		return "login";
	}

	
	  @GetMapping("dash1") private String dash() { return "dash"; }
	 
	/**
	 * Forget-Password
	 * @return
	 */
	@GetMapping("/forgotpassword")
	public String forgot() {
		return "forgotpassword";
	}

	/**User Logout After login && Activities
	 * @param session
	 * @return
	 */
	@GetMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "login";
	}

	/** Show Student DataTable 
	 * @param usermodel
	 * @param model
	 * @param session
	 * @return
	 */
	@GetMapping("/datatable")
	public String datatable(UserModel usermodel, Model model, HttpSession session) {
		if (session.getAttribute("email") != null) {
			model.addAttribute("StudentDetails", service.getAllStudents());
			return "datatable";
		} else {
			return "redirect:/login";
		}
	}

	/** Show Dashboard After Login(Admin OR Students)
	 * @param usermodel
	 * @param session
	 * @return
	 */
	@GetMapping(value = "dashboard")
	public String dashboard(UserModel usermodel, HttpSession session) {
		return "dashboard";
	}

	/** Login Validate Page With login credential 
	 * @param usermodel
	 * @param model
	 * @param EMail
	 * @param rd
	 * @param session
	 * @return
	 */
	@PostMapping("login-validate")
	public String login(UserModel usermodel, Model model, String EMail, RedirectAttributes rd, HttpSession session) {
		if (service.loginpage(usermodel).equals("200")) {
			session.setAttribute("sessionStatus", "true");
			session.setAttribute("email", usermodel.getEMail());
			model.addAttribute("StudentDetails", service.getStudentByEmail(usermodel.getEMail()));
			return "dashboard";
		} else {
			rd.addFlashAttribute("errorMessage", "Please Enter Username or Password");
			return "redirect:/login";
		}
	}

	/** Map View with Autofill data && getBy Address 
	 * @param usermodel
	 * @param model
	 * @param session
	 * @return
	 */
	@GetMapping("map")
	public String map(UserModel usermodel, Model model, HttpSession session) {
		String address = service.userLoction((String) session.getAttribute("email"));
		model.addAttribute("address", address);
		return "map";
	}

	/**Show Multiple Data In GridView list
	 * @param usermodel
	 * @param model
	 * @return
	 */
	@GetMapping("gridlistviewlist")
	public String gridlistviewlist(UserModel usermodel, Model model) {
		model.addAttribute("StudentDetails", service.getAllStudents());
		return "gridlistviewlist";
	}

	/** Show Update Page 
	 * @param usermodel
	 * @param model
	 * @param id
	 * @return
	 * @throws IOException
	 */
	@GetMapping("update-validate")
	public String updateprofile(UserModel usermodel, Model model, String id) throws IOException {
		model.addAttribute("StudentDetails", service.getUserById(id));
		return "updateprofile";
	}

	/** Update user date in Update page With Update credential By Post Mapping
	 * @param usermodel
	 * @param model
	 * @param rd
	 * @param id
	 * @return
	 * @throws IOException
	 */
	@PostMapping("update-validate")
	public String updateprofilepage(UserModel usermodel, Model model, RedirectAttributes rd, Long id)
			throws IOException {
		System.out.println(service.updateuser(usermodel));
		return "dashboard";
	}

	/**Show Students List View With All Data With Images
	 * @param page_id
	 * @param usermodel
	 * @param model
	 * @param session
	 * @return
	 */
	@GetMapping("/studentslist/{page_id}")
	public String list(@PathVariable int page_id, UserModel usermodel, Model model, HttpSession session) {
		if (session.getAttribute("email") != null) {
			int count = service.getCount(usermodel);
			int pageNumber = (count + 6) - count;

			if (page_id == 1) {
			} else {

				page_id = (page_id - 1) * pageNumber + 1;
			}
			model.addAttribute("pageNumber", pageNumber);
			model.addAttribute("StudentDetails", service.getAllStudents());
			model.addAttribute("StudentDetails", service.getUserByPage(page_id, pageNumber));
			model.addAttribute("Pageloop", service.getCount(usermodel));
			return "studentslist";
		} else
			return "redirect:/login";

	}

	/** Show Register (Sign-up) Page
	 * @return
	 */
	@GetMapping(value = "/register")
	public String register() {
		return "register";
	}

	/** Show MyProfile Data After Login 
	 * @param usermodel
	 * @param model
	 * @param id
	 * @param session
	 * @return
	 */
	@GetMapping(value = "profileview")
	public String profileview(UserModel usermodel, Model model, String id, HttpSession session) {
		if (session.getAttribute("email") != null) {
			model.addAttribute("StudentDetails", service.getUserById(id));
			return "profileview";
		} else {
			return "redirect:/login";
		}
	}

	/**  Show Muliple 
	 * @param page_id
	 * @param usermodel
	 * @param model
	 * @param session
	 * @return
	 */
	@GetMapping("/profiles/{page_id}")
	public String profiles(@PathVariable int page_id, UserModel usermodel, Model model, HttpSession session) {
		if (session.getAttribute("email") != null) {
			int count = service.getCount(usermodel);
			int pageNumber = (count + 6) - count;

			if (page_id == 1) {
			} else {

				page_id = (page_id - 1) * pageNumber + 1;
			}
			model.addAttribute("pageNumber", pageNumber);
			model.addAttribute("StudentDetails", service.getAllStudents());
			model.addAttribute("StudentDetails", service.getUserByPage(page_id, pageNumber));
			model.addAttribute("Pageloop", service.getCount(usermodel));
			return "profiles";
		} else
			return "redirect:/login";
	}

	/** Resgister New User With credential Post Mppping
	 * @param usermodel
	 * @param model
	 * @param rd
	 * @return
	 * @throws IOException
	 */
	@PostMapping(value = "register")
	public String registerValidation(UserModel usermodel, Model model, RedirectAttributes rd) throws IOException {

		Integer emailCount = (service.checkEmailAlreadyExist(usermodel));
		if (emailCount <= 0) {
			service.addUser(usermodel);
			return "login";
		} else {
			rd.addFlashAttribute("errorMessage", "Email Allready Exist !!! Please try another Email");
			return "redirect:/register";
		}

	}

	/** ValiDate User And Add user
	 * @param usermodel
	 * @return
	 * @throws IOException
	 */
	@GetMapping(value = "addUser")
	@ResponseBody
	public int addUser(@RequestBody UserModel usermodel) throws IOException {
		return service.addUser(usermodel);
	}

	/** Show Details With Get by User Id
	 * @param id
	 * @return
	 */
	@GetMapping(value = "/getUser/{id}")
	@ResponseBody
	public Map<String, Object> getUserById(@PathVariable String id) {
		return service.getUserById(id);

	}

	/** Delete Data From DataBase By User ID
	 * @param id
	 * @param user
	 * @param rd
	 * @return
	 */
	@GetMapping("/delete")
	public String DeleteById(@RequestParam Long id, UserModel user, RedirectAttributes rd) {
		rd.addFlashAttribute("StudentDetails", service.DeleteById(id));
		return "redirect:/profiles/1";
	}

	/** Forgot Password Abd Retrive Password By SMTP Mail Service 
	 * @param usermodel
	 * @param model
	 * @param session
	 * @param rd
	 * @return
	 */
	@PostMapping("/forgotpassword")
	public String forgotpassword(UserModel usermodel, Model model, HttpSession session, RedirectAttributes rd) {
		if (service.forgotUser(usermodel).equals("Error")) {
			rd.addFlashAttribute("notfound", "Pleae Enter your valid email");
			return "redirect:/forgotpassword";
		} else {
			session.setAttribute("session", usermodel.getEMail());
			rd.addFlashAttribute("send", " Please Check Your Mail!");
			return "redirect:/login";
		}
	}
	/** Check Amil At Run Time USing With Ajex 
	 * @param email
	 * @return
	 */
	@GetMapping("/emailAlreadyExist/{email}")
	public Map<String, Object> checkEmailAlreadyExist(@PathVariable String email) {
		Map<String, Object> map= new HashMap<>();
		map.put("Success",200);
		return map;
	}

}
