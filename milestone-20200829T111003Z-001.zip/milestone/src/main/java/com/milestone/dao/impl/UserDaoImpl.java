package com.milestone.dao.impl;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.milestone.dao.UserDao;
import com.milestone.model.UserModel;
@Repository
public class UserDaoImpl  implements UserDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	/* (non-Javadoc)
	 * @see com.milestone.dao.UserDao#getPaaswordByEmail(com.milestone.model.UserModel)
	 */
	@Override
	public String getPaaswordByEmail(UserModel usermodel) {
		return jdbcTemplate.queryForObject("select Password from student_table where EMail=?",String.class ,usermodel.getEMail());
	}
	

	/* (non-Javadoc)
	 * @see com.milestone.dao.UserDao#checkEmailAlreadyExist(com.milestone.model.UserModel)
	 */
	@Override
	public int checkEmailAlreadyExist(UserModel usermodel) {
		return jdbcTemplate.queryForObject("select count(*) from student_table where EMail=?",Integer.class,usermodel.getEMail());
	}

	/* (non-Javadoc)
	 * @see com.milestone.dao.UserDao#getStudentByEmail(java.lang.String)
	 */
	@Override
	public Map<String, Object> getStudentByEmail(String EMail) {
		return jdbcTemplate.queryForMap ("select StudentID,FirstName,LastName,EMail,Password,ConfirmPaasword,Role,ProfilePic,Gender,MaritalStatus,Hobbies from student_table where EMail=?"
				,EMail);
	}
	/* (non-Javadoc)
	 * @see com.milestone.dao.UserDao#getAllStudents()
	 */
	@Override
	public List<Map<String, Object>> getAllStudents() {
		
		return jdbcTemplate.queryForList("select * from student_table");
	}
	/* (non-Javadoc)
	 * @see com.milestone.dao.UserDao#addUser(com.milestone.model.UserModel)
	 */
	@Override
	public int addUser(UserModel usermodel) {
		String sql="INSERT INTO student_table (FirstName, LastName, EMail, Password, ConfirmPaasword, Role, ProfilePic, Gender, MaritalStatus, Hobbies, DOB, Address, MobileNumber, Fee) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		return jdbcTemplate.update(sql,usermodel.getFirstName(),usermodel.getLastName(),
				usermodel.getEMail(),usermodel.getPassword(),usermodel.getConfirmPaasword(),usermodel.getRole(),usermodel.getProfilePic().getOriginalFilename(),usermodel.getGender(),usermodel.getMaritalStatus(),usermodel.getHobbies(),usermodel.getDOB(),usermodel.getAddress(),usermodel.getMobileNumber(),usermodel.getFee());		
	}
	/* (non-Javadoc)
	 * @see com.milestone.dao.UserDao#addUserWithoutImage(com.milestone.model.UserModel)
	 */
	@Override
	public int addUserWithoutImage(UserModel usermodel) {
		String sql="INSERT INTO student_table (FirstName, LastName, EMail, Password, ConfirmPaasword, Role, Gender, MaritalStatus, Hobbies, DOB, Address, MobileNumber, Fee) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
		return jdbcTemplate.update(sql,usermodel.getFirstName(),usermodel.getLastName(),
				usermodel.getEMail(),usermodel.getPassword(),usermodel.getConfirmPaasword(),usermodel.getRole(),usermodel.getGender(),usermodel.getMaritalStatus(),usermodel.getHobbies(),usermodel.getDOB(),usermodel.getAddress(),usermodel.getMobileNumber(),usermodel.getFee());
	}
	/* (non-Javadoc)
	 * @see com.milestone.dao.UserDao#getUserById(java.lang.String)
	 */
	@Override
	public Map<String, Object> getUserById(String id) {
		return jdbcTemplate.queryForMap("select StudentID, FirstName, LastName, EMail, Password, ConfirmPaasword , Role, ProfilePic, Gender, MaritalStatus, Hobbies from student_table where StudentID=?",
				id);
	}
	/* (non-Javadoc)
	 * @see com.milestone.dao.UserDao#DeleteById(java.lang.Long)
	 */
	@Override
	public int DeleteById(Long id) {
		String save="DELETE FROM student_table WHERE StudentID=?";
		return jdbcTemplate.update(save,id);
	}
	/* (non-Javadoc)
	 * @see com.milestone.dao.UserDao#updateuser(com.milestone.model.UserModel)
	 */
	@Override
	public int updateuser(UserModel usermodel) {
	String sql= ("UPDATE student_table SET StudentID=?,FirstName=?, LastName=?,EMail=?, Password=?, ConfirmPaasword =?, Role=?,ProfilePic=?, Gender=?, MaritalStatus=?, Hobbies=?, DOB=?, Address=?, MobileNumber=?,Fee=? WHERE StudentID =?");
	System.out.println(sql);
	return jdbcTemplate.update(sql,usermodel.getStudentID(),usermodel.getFirstName(),usermodel.getLastName(),usermodel.getEMail(),
			usermodel.getPassword(),usermodel.getConfirmPaasword(),usermodel.getRole(),usermodel.getProfilePic().getOriginalFilename(),usermodel.getGender(),usermodel.getMaritalStatus(),usermodel.getHobbies(),usermodel.getDOB(),usermodel.getAddress(),usermodel.getMobileNumber(),usermodel.getFee(),usermodel.getStudentID());
}
	 /* (non-Javadoc)
	 * @see com.milestone.dao.UserDao#updateUserWithoutImage(com.milestone.model.UserModel)
	 */
	@Override public int updateUserWithoutImage(UserModel usermodel) { String
	 sql=
	  ("UPDATE student_table SET StudentID=?,FirstName=?, LastName=?,EMail=?, Password=?, ConfirmPaasword =?, Role=?,Gender=?, MaritalStatus=?, Hobbies=?, DOB=?, Address=?, MobileNumber=?,Fee=?  WHERE StudentID =?"
	  );
	 System.out.println(sql);
	 return
	  jdbcTemplate.update(sql,usermodel.getStudentID(),usermodel.getFirstName(),
	  usermodel.getLastName(),usermodel.getEMail(),
	  usermodel.getPassword(),usermodel.getConfirmPaasword(),usermodel.getRole(),
	  usermodel.getGender(),usermodel.getMaritalStatus(),usermodel.getHobbies(),usermodel.getDOB(),usermodel.getAddress(),
	  usermodel.getMobileNumber(),usermodel.getFee(),
	  usermodel.getStudentID()); }
	/* (non-Javadoc)
	 * @see com.milestone.dao.UserDao#getUserByPage(int, int)
	 */
	@Override
	public List<Map<String, Object>> getUserByPage(int page_id, int total) {
		String str="SELECT * FROM student_table LIMIT " + (page_id-1) + "," + total;
		return jdbcTemplate.queryForList(str);
	}
	/* (non-Javadoc)
	 * @see com.milestone.dao.UserDao#getCount(com.milestone.model.UserModel)
	 */
	@Override
	public int getCount(UserModel usermodel) {
		String str="select count(*) from student_table";
		return jdbcTemplate.queryForObject(str, Integer.class);
	}
	/* (non-Javadoc)
	 * @see com.milestone.dao.UserDao#getRole(com.milestone.model.UserModel)
	 */
	@Override
	public String getRole(UserModel usermodel) {
		String str = "Select Role from student_table where EMail=?";
		return jdbcTemplate.queryForObject(str, String.class, usermodel.getEMail());
	}
	/* (non-Javadoc)
	 * @see com.milestone.dao.UserDao#userLoction(java.lang.String)
	 */
	@Override
	public String userLoction(String EMail) {
			String str="SELECT Address from student_table where EMail=?";
		return jdbcTemplate.queryForObject(str, String.class, EMail);
	}

}
