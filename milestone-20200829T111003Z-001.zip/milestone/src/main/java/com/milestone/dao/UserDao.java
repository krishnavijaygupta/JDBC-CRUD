package com.milestone.dao;

import java.util.List;
import java.util.Map;

import com.milestone.model.UserModel;

public interface UserDao {


	String getPaaswordByEmail(UserModel usermodel);

	Map<String, Object> getStudentByEmail(String EMail);


	List<Map<String, Object>> getAllStudents();


	int addUser(UserModel usermodel);


	Map<String, Object> getUserById(String id);


	int DeleteById(Long id);


	int updateuser(UserModel usermodel);


	int checkEmailAlreadyExist(UserModel usermodel);


	List<Map<String, Object>> getUserByPage(int page_id, int total);

	int getCount(UserModel usermodel);

	int updateUserWithoutImage(UserModel usermodel);

	int addUserWithoutImage(UserModel usermodel);

	String getRole(UserModel usermodel);

	public String userLoction(String EMail);


}
