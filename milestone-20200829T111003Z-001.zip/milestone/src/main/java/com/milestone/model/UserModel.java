package com.milestone.model;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

@Component
public class UserModel {

	private Long studentID;
	private String FirstName;
	private String LastName;
	private String EMail;
	private String Password;
	private String ConfirmPaasword;
	private String Role;
	private MultipartFile ProfilePic;
	private String Gender;
	private String MaritalStatus;
	private String Hobbies;
	private String DOB;
	private String Address;
	private Long MobileNumber;
	private String Fee;
	
	public Long getStudentID() {
		return studentID;
	}
	public void setStudentID(Long studentID) {
		this.studentID = studentID;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		this.FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		this.LastName = lastName;
	}
	public String getEMail() {
		return EMail;
	}
	public void setEMail(String eMail) {
		this.EMail = eMail;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		this.Password = password;
	}
	public String getConfirmPaasword() {
		return ConfirmPaasword;
	}
	public void setConfirmPaasword(String confirmPaasword) {
		this.ConfirmPaasword = confirmPaasword;
	}
	public String getRole() {
		return Role;
	}
	public void setRole(String role) {
		this.Role = role;
	}
	
	public MultipartFile getProfilePic() {
		return ProfilePic;
	}
	public void setProfilePic(MultipartFile profilePic) {
		ProfilePic = profilePic;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		this.Gender = gender;
	}
	public String getMaritalStatus() {
		return MaritalStatus;
	}
	public void setMaritalStatus(String maritalStatus) {
		this.MaritalStatus = maritalStatus;
	}
	public String getHobbies() {
		return Hobbies;
	}
	public void setHobbies(String hobbies) {
		this.Hobbies = hobbies;
	}
	
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String dOB) {
		DOB = dOB;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public Long getMobileNumber() {
		return MobileNumber;
	}
	public void setMobileNumber(Long mobileNumber) {
		MobileNumber = mobileNumber;
	}
	public String getFee() {
		return Fee;
	}
	public void setFee(String fee) {
		Fee = fee;
	}

	public UserModel(Long studentID, String firstName, String lastName, String eMail, String password,
			String confirmPaasword, String role, MultipartFile profilePic, String gender, String maritalStatus,
			String hobbies, String dOB, String address, Long mobileNumber, String fee ) {
		super();
		this.studentID = studentID;
		this.FirstName = firstName;
		this.LastName = lastName;
		this.EMail = eMail;
		this.Password = password;
		this.ConfirmPaasword = confirmPaasword;
		this.Role = role;
		this.ProfilePic = profilePic;
		this.Gender = gender;
		this.MaritalStatus = maritalStatus;
		this.Hobbies = hobbies;
		this.DOB = dOB;
		this.Address = address;
		this.MobileNumber = mobileNumber;
		this.Fee = fee;
	}
	
	public UserModel() {
		super();
	}
	@Override
	public String toString() {
		return "UserModel [studentID=" + studentID + ", FirstName=" + FirstName + ", LastName=" + LastName + ", EMail="
				+ EMail + ", Password=" + Password + ", ConfirmPaasword=" + ConfirmPaasword + ", Role=" + Role
				+ ", ProfilePic=" + ProfilePic + ", Gender=" + Gender + ", MaritalStatus=" + MaritalStatus
				+ ", Hobbies=" + Hobbies + ", DOB=" + DOB + ", Address=" + Address + ", MobileNumber=" + MobileNumber
				+ ", Fee=" + Fee + "]";
	}
	
	
	
}
