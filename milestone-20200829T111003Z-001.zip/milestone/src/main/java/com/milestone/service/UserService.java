package com.milestone.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.milestone.model.UserModel;

public interface UserService {

	String loginpage(UserModel usermodel);

	Object getAllStudents();

	int addUser(UserModel usermodel) throws IOException;

	Map<String, Object> getUserById(String id);

	int DeleteById(Long id);

	int updateuser(UserModel usermodel) throws IOException;

	Map<String, Object> getStudentByEmail(String EMail);

	int checkEmailAlreadyExist(UserModel usermodel);

	int getCount(UserModel usermodel);

	public List<Map<String, Object>> getUserByPage(int page_id, int total);

	String forgotUser(UserModel usermodel);

	String getUserByRole(UserModel usermodel);
	
	public String userLoction(String EMail);

}
