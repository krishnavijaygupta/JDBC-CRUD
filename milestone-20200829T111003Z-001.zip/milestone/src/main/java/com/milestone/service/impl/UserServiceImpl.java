package com.milestone.service.impl;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.milestone.dao.UserDao;
import com.milestone.model.UserModel;
import com.milestone.service.UserService;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private JavaMailSender sender;
	
	@Autowired
	UserDao userdao;
	
//	@Autowired
	@Value("${file.path-pic}")
	
	private String folder;
	/* (non-Javadoc)
	 * @see com.milestone.service.UserService#getAllStudents()
	 */
	@Override
	public List<Map<String,Object>>getAllStudents() {
		return userdao.getAllStudents();
	}
	
	/* (non-Javadoc)
	 * @see com.milestone.service.UserService#loginpage(com.milestone.model.UserModel)
	 */
	@Override
	public String loginpage(UserModel usermodel) {
		
		try {
			if (usermodel.getPassword().equals(userdao.getPaaswordByEmail(usermodel))) {
				return "200";
			} else {
				return "300";
			}
		} catch (Exception e) {
			return "error";

		}
		
	}
	
	/* (non-Javadoc)
	 * @see com.milestone.service.UserService#addUser(com.milestone.model.UserModel)
	 */
	@Override
	public int addUser(UserModel usermodel) throws IOException {
		
		if(usermodel.getProfilePic().isEmpty()) {
			return userdao.addUserWithoutImage(usermodel);
		}
		else {
		
	    String filePath= StringUtils.cleanPath(usermodel.getProfilePic().getOriginalFilename());
		Path path=Paths.get(folder+filePath);
        Files.copy(usermodel.getProfilePic().getInputStream(),path,StandardCopyOption.REPLACE_EXISTING);
        return userdao.addUser(usermodel);
	}
	}
	
	/* (non-Javadoc)
	 * @see com.milestone.service.UserService#getUserById(java.lang.String)
	 */
	@Override
	public Map<String, Object> getUserById(String id) {
		return userdao.getUserById(id);
	}
	


	/* (non-Javadoc)
	 * @see com.milestone.service.UserService#getStudentByEmail(java.lang.String)
	 */
	@Override
	public Map<String, Object> getStudentByEmail(String EMail) {
		return userdao.getStudentByEmail(EMail);
	}

	/* (non-Javadoc)
	 * @see com.milestone.service.UserService#DeleteById(java.lang.Long)
	 */
	@Override
	public int DeleteById(Long id) {
		return userdao.DeleteById(id);
	}

	/* (non-Javadoc)
	 * @see com.milestone.service.UserService#updateuser(com.milestone.model.UserModel)
	 */
	@Override
	public int updateuser(UserModel usermodel) throws IOException {
		
		if(usermodel.getProfilePic().isEmpty()) {
			return userdao.updateUserWithoutImage(usermodel);
		}
		else {
		
		String filePath= StringUtils.cleanPath(usermodel.getProfilePic().getOriginalFilename());
		Path path=Paths.get(folder+filePath);
        long copy=Files.copy(usermodel.getProfilePic().getInputStream(),path,StandardCopyOption.REPLACE_EXISTING);
		return userdao.updateuser(usermodel);
	}
		}

	/* (non-Javadoc)
	 * @see com.milestone.service.UserService#checkEmailAlreadyExist(com.milestone.model.UserModel)
	 */
	@Override
	public int checkEmailAlreadyExist(UserModel usermodel) {
		return userdao.checkEmailAlreadyExist(usermodel);
	}

	/* (non-Javadoc)
	 * @see com.milestone.service.UserService#getCount(com.milestone.model.UserModel)
	 */
	@Override
	public int getCount(UserModel usermodel) {
	float f= userdao.getCount(usermodel)/3;
	return (int)Math.ceil(1);
	}

	/* (non-Javadoc)
	 * @see com.milestone.service.UserService#getUserByPage(int, int)
	 */
	@Override
	public List<Map<String, Object>> getUserByPage(int page_id, int total) {
		return userdao.getUserByPage(page_id, total);	}

	/* (non-Javadoc)
	 * @see com.milestone.service.UserService#forgotUser(com.milestone.model.UserModel)
	 */
	@Override
	public String forgotUser(UserModel usermodel) {
		
		MimeMessage message = sender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message);

		try {
			helper.setTo(usermodel.getEMail());
			helper.setText("Your Password is : " + userdao.getPaaswordByEmail(usermodel));
			helper.setSubject("Mail From Spring Boot");
		} catch (MessagingException e) {
			e.printStackTrace();
			return "Error while sending mail ..";
		}
		sender.send(message);
		return "message sent";
	}

	/* (non-Javadoc)
	 * @see com.milestone.service.UserService#getUserByRole(com.milestone.model.UserModel)
	 */
	@Override
	public String getUserByRole(UserModel usermodel) {
		try {
			if (userdao.getRole(usermodel).equals("Admin")) {
				return "200";
			} else {
				return "201";
			}
		} catch (Exception e) {
			return "error";
		}
	}

	/* (non-Javadoc)
	 * @see com.milestone.service.UserService#userLoction(java.lang.String)
	 */
	@Override
	public String userLoction(String EMail) {
		
		return userdao.userLoction(EMail);
	}


	
}
